﻿using Microsoft.SqlServer.Management.Smo;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace DevConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            DataTable dt = SmoApplication.EnumAvailableSqlServers(true);
            DataRow[] rows = dt.Select(string.Empty, "IsLocal desc, Name asc");
            var a = HasAdminRights();
        }

        private static bool HasAdminRights()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }
}
